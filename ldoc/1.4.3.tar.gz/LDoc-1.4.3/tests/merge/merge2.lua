----
-- submodule
-- @module merge

---- second fun
-- @param x
function two(x)
end

--- extra stuff
-- @section extra

--- third fun
function three ()
end

--- fourth fun
function four ()
end
