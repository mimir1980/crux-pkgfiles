--- simplified LDoc colon style.
-- You have to use -C flag or 'colon=true' for this one!
module 'easy'

--- First one.
-- string: name
-- int: age
function first(name,age) end
