------
-- functions returning compound types
-- @module struct

-----
-- returns a 'struct'.
-- @string name your name dammit
-- @tfield string arb stuff
-- @treturn st details of person
-- @tfield[st] string name of person
-- @tfield[st] int age of person
function struct(name) end

